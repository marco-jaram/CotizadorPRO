package com.tuempresa.cotizador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CotizadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
