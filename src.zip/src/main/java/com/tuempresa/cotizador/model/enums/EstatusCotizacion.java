
package com.tuempresa.cotizador.model.enums;

public enum EstatusCotizacion {
    BORRADOR,
    ENVIADA,
    APROBADA,
    RECHAZADA
}